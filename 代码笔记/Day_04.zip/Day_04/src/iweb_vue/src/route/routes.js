// 引入组件
import Home from "../pages/Home"

export const routes = [
  {
    path: "/",
    name: "home",
    component: Home
  }
  // {
  // 其它路由
  // }
];