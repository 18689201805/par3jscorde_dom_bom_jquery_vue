<template>
  <b-container>
    <h1>这里是首页</h1>
    <b-button>Button</b-button>
    <b-button variant="danger">Button</b-button>
    <b-button variant="success">Button</b-button>
    <b-button variant="outline-primary">Button</b-button>
  </b-container>
</template>

<script>
export default {
  name: "Home"
}
</script>

<style>
  
</style>