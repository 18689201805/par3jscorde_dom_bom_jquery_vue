<template>
  <b-container class="my-5">
    <b-row>
      <b-col md="8">
        <b-row>
          <b-col cols="3">
            <h5>关于i前端</h5>
            <ul class="list-unstyled">
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
            </ul>
          </b-col>
          <b-col cols="3">
            <h5>关于i前端</h5>
            <ul class="list-unstyled">
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
            </ul>
          </b-col>
          <b-col cols="3">
            <h5>关于i前端</h5>
            <ul class="list-unstyled">
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
            </ul>
          </b-col>
          <b-col cols="3">
            <h5>关于i前端</h5>
            <ul class="list-unstyled">
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
              <li><a href="#">发展历程</a></li>
            </ul>
          </b-col>
        </b-row>
      </b-col>
      <b-col md="4" class="py-5">
        <dt></dt>
        <dd>客服热线<br/>4008-220-220 ( 9:00 - 24:00 )</dd>
      </b-col>
    </b-row>
    <b-row>
      <!-- 页脚的下半部分 -->
    </b-row>
  </b-container>
</template>

<script>
export default {
  name: "Footer"
}
</script>

<style lang="">
  
</style>